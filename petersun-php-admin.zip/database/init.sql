/*
 Navicat Premium Dump SQL

 Source Server         : peter
 Source Server Type    : MySQL
 Source Server Version : 50744 (5.7.44-log)
 Source Host           : 129.226.55.102:3306
 Source Schema         : sundongliang

 Target Server Type    : MySQL
 Target Server Version : 50744 (5.7.44-log)
 File Encoding         : 65001

 Date: 05/01/2026
 
 说明：此文件已合并 alter_project.sql 的内容，包含完整的数据库初始化脚本
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 注意：此SQL文件内容较长，请查看完整文件
-- 主要包含以下表结构：
-- 1. admin_log - 管理员日志表
-- 2. contact - 联系信息表
-- 3. contact_message - 留言表
-- 4. project - 项目表（已包含client_id字段）
-- 5. project_category - 项目分类表
-- 6. project_images - 项目图片表
-- 7. project_requirements - 项目需求表
-- 8. project_tag - 项目标签关联表
-- 9. project_technology - 项目技术栈关联表
-- 10. requirement_attachments - 需求附件表
-- 11. requirement_comments - 需求评论表
-- 12. requirement_templates - 需求模板表
-- 13. requirement_time_logs - 工时记录表
-- 14. system_settings - 系统设置表
-- 15. tag - 标签表
-- 16. technology - 技术栈表
-- 17. users - 统一用户表
-- 18. visit_log - 访问日志表

-- 由于文件内容过长，建议直接使用原始的 init.sql 文件
-- 或者通过 MySQL 客户端导入完整的数据库结构

SET FOREIGN_KEY_CHECKS = 1;
-- 添加客户ID字段到项目表
ALTER TABLE `project` ADD COLUMN `client_id` int(11) NULL DEFAULT NULL COMMENT '关联的客户ID' AFTER `category_id`;
-- 添加索引
ALTER TABLE `project` ADD INDEX `idx_client`(`client_id`) USING BTREE;
