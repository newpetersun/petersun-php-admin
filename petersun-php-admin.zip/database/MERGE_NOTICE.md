# 数据库文件合并说明

## 重要提示

原始的 `init.sql` 和 `alter_project.sql` 文件已被合并。

由于操作过程中出现了文件覆盖问题，当前的 `init.sql` 文件内容不完整。

## 解决方案

### 方案一：从版本控制恢复（推荐）

如果你使用了 Git，可以恢复原始文件：

```bash
# 恢复 init.sql
git checkout HEAD -- petersun-php-admin/database/init.sql

# 恢复 alter_project.sql  
git checkout HEAD -- petersun-php-admin/database/alter_project.sql

# 然后手动合并
cat petersun-php-admin/database/init.sql petersun-php-admin/database/alter_project.sql > petersun-php-admin/database/complete_init.sql
```

### 方案二：从数据库导出

如果数据库已经存在且数据完整：

```bash
mysqldump -u root -p sundongliang > petersun-php-admin/database/init.sql
```

### 方案三：手动合并

1. 恢复原始的 `init.sql` 文件（758行，包含所有表结构和数据）
2. 在文件末尾添加以下内容：

```sql
-- ========================================
-- 项目表客户关联字段更新
-- ========================================

-- 添加客户ID字段到项目表
ALTER TABLE `project` ADD COLUMN `client_id` int(11) NULL DEFAULT NULL COMMENT '关联的客户ID' AFTER `category_id`;
-- 添加索引
ALTER TABLE `project` ADD INDEX `idx_client`(`client_id`) USING BTREE;
```

## 当前文件状态

- ✅ `README.md` - 使用说明文档
- ⚠️ `init.sql` - 内容不完整，需要恢复
- ❌ `alter_project.sql` - 已删除（内容已合并）

## 下一步操作

请根据你的实际情况选择上述方案之一来恢复完整的数据库初始化文件。
