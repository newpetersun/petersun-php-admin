# 数据库文件说明

## 文件列表

1. **init.sql** - 完整的数据库初始化脚本
   - 包含所有表结构和初始数据
   - 约 758 行
   
2. **alter_project.sql** - 项目表更新脚本
   - 为 project 表添加 client_id 字段
   - 添加客户关联索引

## 使用方法

### 方式一：分步执行（推荐）

```bash
# 1. 先执行初始化脚本
mysql -u root -p sundongliang < init.sql

# 2. 再执行更新脚本
mysql -u root -p sundongliang < alter_project.sql
```

### 方式二：合并后执行

如果需要合并成一个文件，可以手动操作：

**Windows (CMD):**
```cmd
copy init.sql + alter_project.sql complete_init.sql
```

**Windows (PowerShell):**
```powershell
Get-Content init.sql, alter_project.sql | Set-Content complete_init.sql
```

**Linux/Mac:**
```bash
cat init.sql alter_project.sql > complete_init.sql
```

## 注意事项

1. `alter_project.sql` 中的更新已经在 `init.sql` 的 project 表结构中体现
2. 如果是全新安装，只需执行 `init.sql` 即可
3. 如果数据库已存在且需要添加 client_id 字段，执行 `alter_project.sql`
4. 执行前请确保数据库 `sundongliang` 已创建

## 数据库配置

修改 `.env` 文件中的数据库配置：

```env
DB_TYPE = mysql
DB_HOST = 127.0.0.1
DB_NAME = sundongliang
DB_USER = root
DB_PASS = your_password
DB_PORT = 3306
DB_CHARSET = utf8
```
