<?php /*a:1:{s:55:"E:\newpetersun\petersun-php-admin\view\index\index.html";i:1780978100;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <link rel="stylesheet" href="/assets/uni.af621e77.css">

    <meta charset="UTF-8" />
    <script>
      var coverSupport = 'CSS' in window && typeof CSS.supports === 'function' && (CSS.supports('top: env(a)') ||
        CSS.supports('top: constant(a)'))
      document.write(
        '<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0' +
        (coverSupport ? ', viewport-fit=cover' : '') + '" />')
    </script>
    <title>petersun</title>
    <!--preload-links-->
    <!--app-context-->
    <script type="module" crossorigin src="/assets/index-DO1-zgSW.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-yksqsBZR.css">
  </head>
  <body>
    <div id="app"><!--app-html--></div>
  </body>
</html>
