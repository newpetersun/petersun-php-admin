<?php
declare(strict_types=1);

namespace app\controller;

use app\BaseController;
use think\Request;
use think\facade\Db;
use think\Response;

/**
 * 创作者内容控制器（图文 / 视频 / 草稿 / 发布审核）
 *
 * 一张 articles 表承载「我的图文、我的视频、草稿箱、发布管理」四个页面。
 *
 * status 状态机：
 *   draft -> pending（提交发布）-> approved（通过）/ rejected（驳回）
 *   approved <-> offline（下架/上架）；rejected -> pending（重新提交）
 */
class Article extends BaseController
{
    private const TYPES = ['image_text', 'video'];

    private const STATUS_TEXT = [
        'draft'    => '草稿',
        'pending'  => '待审核',
        'approved' => '已发布',
        'rejected' => '已驳回',
        'offline'  => '已下架',
    ];

    /** 列表：我的图文 / 我的视频 / 发布管理 共用 */
    public function list(Request $request): Response
    {
        try {
            $uid = $this->uid($request);
            if ($uid === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $type    = trim((string) $request->param('type', ''));
            $status  = trim((string) $request->param('status', ''));
            $keyword = trim((string) $request->param('keyword', ''));
            [$page, $limit] = $this->paging($request);

            if ($type !== '' && !in_array($type, self::TYPES, true)) {
                return json(['code' => 400, 'message' => '内容类型不正确']);
            }
            if ($status !== '' && !isset(self::STATUS_TEXT[$status])) {
                return json(['code' => 400, 'message' => '状态值不正确']);
            }

            $where = [['user_id', '=', $uid]];
            if ($type !== '') {
                $where[] = ['type', '=', $type];
            }
            if ($status !== '') {
                $where[] = ['status', '=', $status];
            } else {
                $where[] = ['status', '<>', 'draft'];
            }
            if ($keyword !== '') {
                $where[] = ['title', 'like', "%{$keyword}%"];
            }

            $rows = Db::name('articles')->where($where)
                ->order('update_time', 'desc')->order('id', 'desc')
                ->paginate(['list_rows' => $limit, 'page' => $page]);

            $list = array_map([$this, 'formatItem'], $rows->items());

            return $this->ok(['list' => $list, 'total' => $rows->total(), 'page' => $page, 'limit' => $limit]);
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 详情：作者本人、或管理端、或已发布内容 */
    public function detail(Request $request, $id): Response
    {
        try {
            $row = Db::name('articles')->where('id', $id)->find();
            if (!$row) {
                return json(['code' => 404, 'message' => '内容不存在']);
            }
            // 作者本人 / 管理端（审核需查看未发布内容）/ 已发布内容
            $isAdmin = (bool) ($request->isAdmin ?? false);
            if ($row['user_id'] !== $this->uid($request) && !$isAdmin && $row['status'] !== 'approved') {
                return json(['code' => 403, 'message' => '无权查看该内容']);
            }

            $data = $this->formatItem($row);
            $data['content'] = (string) ($row['content'] ?? '');
            $data['videoUrl'] = (string) ($row['video_url'] ?? '');

            return $this->ok($data);
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 新建：submit=1 直接提交审核，否则仅存草稿 */
    public function save(Request $request): Response
    {
        try {
            $uid = $this->uid($request);
            if ($uid === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $data = $this->readForm($request);
            if (isset($data['__error'])) {
                return json(['code' => 400, 'message' => $data['__error']]);
            }

            $submit = (bool) $request->param('submit', 0);
            $data['user_id']       = $uid;
            $data['status']        = $submit ? 'pending' : 'draft';
            $data['submit_time']   = $submit ? date('Y-m-d H:i:s') : null;
            $data['reject_reason'] = null;
            $data['create_time']   = date('Y-m-d H:i:s');
            $data['update_time']   = date('Y-m-d H:i:s');
            $data['id']            = uuid();

            Db::name('articles')->insert($data);

            return $this->ok(
                ['id' => $data['id'], 'status' => $data['status']],
                $submit ? '已提交发布' : '草稿已保存'
            );
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 更新：仅 draft|rejected|offline 可编辑 */
    public function update(Request $request, $id): Response
    {
        try {
            $uid = $this->uid($request);
            if ($uid === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $row = Db::name('articles')->where('id', $id)->find();
            if (!$row) {
                return json(['code' => 404, 'message' => '内容不存在']);
            }
            if ($row['user_id'] !== $uid) {
                return json(['code' => 403, 'message' => '无权编辑该内容']);
            }
            if (in_array($row['status'], ['pending', 'approved'], true)) {
                return json(['code' => 400, 'message' => '审核中或已发布的内容不可编辑，请先下架']);
            }

            $data = $this->readForm($request);
            if (isset($data['__error'])) {
                return json(['code' => 400, 'message' => $data['__error']]);
            }

            $submit = (bool) $request->param('submit', 0);
            $data['status']        = $submit ? 'pending' : $row['status'];
            $data['submit_time']   = $submit ? date('Y-m-d H:i:s') : $row['submit_time'];
            $data['reject_reason'] = $submit ? null : $row['reject_reason'];
            $data['update_time']   = date('Y-m-d H:i:s');

            // 封面 / 视频地址为可选字段：未传时保留原值，避免误清空
            if (!$request->has('cover')) {
                unset($data['cover']);
            }
            if (!$request->has('video_url')) {
                unset($data['video_url']);
            }
            if (!$request->has('duration')) {
                unset($data['duration']);
            }

            Db::name('articles')->where('id', $id)->update($data);

            return $this->ok(['id' => $id, 'status' => $data['status']], $submit ? '已提交发布' : '保存成功');
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 删除：仅 draft|rejected|offline 可删除 */
    public function delete(Request $request, $id): Response
    {
        try {
            $uid = $this->uid($request);
            if ($uid === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $row = Db::name('articles')->where('id', $id)->find();
            if (!$row) {
                return json(['code' => 404, 'message' => '内容不存在']);
            }
            if ($row['user_id'] !== $uid) {
                return json(['code' => 403, 'message' => '无权删除该内容']);
            }
            if (in_array($row['status'], ['pending', 'approved'], true)) {
                return json(['code' => 400, 'message' => '审核中或已发布的内容不可删除，请先下架']);
            }

            Db::name('articles')->where('id', $id)->delete();
            Db::name('article_comments')->where('article_id', $id)->delete();
            Db::name('article_daily_stats')->where('article_id', $id)->delete();

            return $this->ok(null, '删除成功');
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 上下架 / 重新提交：approved<->offline，draft|rejected->pending */
    public function toggleStatus(Request $request, $id): Response
    {
        try {
            $uid = $this->uid($request);
            if ($uid === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $row = Db::name('articles')->where('id', $id)->find();
            if (!$row) {
                return json(['code' => 404, 'message' => '内容不存在']);
            }
            if ($row['user_id'] !== $uid) {
                return json(['code' => 403, 'message' => '无权操作该内容']);
            }

            $map = [
                'approved' => 'offline',
                'offline'  => 'approved',
                'draft'    => 'pending',
                'rejected' => 'pending',
            ];
            $from = (string) $row['status'];
            if (!isset($map[$from])) {
                return json(['code' => 400, 'message' => '当前状态不支持该操作']);
            }
            $to = $map[$from];

            $update = ['status' => $to, 'update_time' => date('Y-m-d H:i:s')];
            if ($to === 'pending') {
                $update['submit_time']   = date('Y-m-d H:i:s');
                $update['reject_reason'] = null;
            }
            Db::name('articles')->where('id', $id)->update($update);

            return $this->ok([
                'id'         => $id,
                'status'     => $to,
                'statusText' => self::STATUS_TEXT[$to],
            ]);
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /**
     * 批量操作：下架 / 上架 / 提交审核 / 删除
     * action: offline(下架) | approve(上架) | submit(提交审核) | delete(删除)
     * 逐条校验归属与状态，单条失败不影响其他条目，返回成功/失败明细
     */
    public function batch(Request $request): Response
    {
        try {
            $uid = $this->uid($request);
            if ($uid === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $ids = $request->param('ids', []);
            if (is_string($ids)) {
                $ids = explode(',', $ids);
            }
            $ids = array_values(array_unique(array_filter((array) $ids, function ($v) {
                return $v !== '' && $v !== null;
            })));
            if (!$ids) {
                return json(['code' => 400, 'message' => '请先选择要操作的内容']);
            }
            if (count($ids) > 100) {
                return json(['code' => 400, 'message' => '单次最多操作 100 条']);
            }

            $action = trim((string) $request->param('action', ''));
            $rules = [
                'offline' => ['from' => ['approved'], 'to' => 'offline'],
                'approve' => ['from' => ['offline'], 'to' => 'approved'],
                'submit'  => ['from' => ['draft', 'rejected'], 'to' => 'pending'],
            ];
            $isDelete = $action === 'delete';
            if (!$isDelete && !isset($rules[$action])) {
                return json(['code' => 400, 'message' => '不支持的批量操作']);
            }

            // 仅取本人的内容，越权/不存在的条目在下方统一记为失败
            $rows = Db::name('articles')
                ->where('id', 'in', $ids)
                ->where('user_id', $uid)
                ->select()
                ->toArray();
            $rowMap = [];
            foreach ($rows as $r) {
                $rowMap[(string) $r['id']] = $r;
            }

            $now     = date('Y-m-d H:i:s');
            $success = [];
            $failed  = [];

            Db::startTrans();
            try {
                foreach ($ids as $id) {
                    $id    = (string) $id;
                    $row   = $rowMap[$id] ?? null;
                    $title = $row ? (string) ($row['title'] ?? '') : '';

                    if (!$row) {
                        $failed[] = ['id' => $id, 'title' => '', 'reason' => '内容不存在或无权操作'];
                        continue;
                    }
                    $from = (string) $row['status'];

                    if ($isDelete) {
                        // 与单个删除保持一致：审核中/已发布需先下架
                        if (in_array($from, ['pending', 'approved'], true)) {
                            $failed[] = [
                                'id'     => $id,
                                'title'  => $title,
                                'reason' => '「' . $title . '」' . (self::STATUS_TEXT[$from] ?? $from) . '状态不可删除，请先下架',
                            ];
                            continue;
                        }
                        Db::name('articles')->where('id', $id)->delete();
                        Db::name('article_comments')->where('article_id', $id)->delete();
                        Db::name('article_daily_stats')->where('article_id', $id)->delete();
                        $success[] = ['id' => $id, 'title' => $title];
                        continue;
                    }

                    $rule = $rules[$action];
                    if (!in_array($from, $rule['from'], true)) {
                        $failed[] = [
                            'id'     => $id,
                            'title'  => $title,
                            'reason' => '「' . $title . '」当前为' . (self::STATUS_TEXT[$from] ?? $from) . '，不支持该操作',
                        ];
                        continue;
                    }

                    $update = ['status' => $rule['to'], 'update_time' => $now];
                    if ($rule['to'] === 'pending') {
                        $update['submit_time']   = $now;
                        $update['reject_reason'] = null;
                    }
                    Db::name('articles')->where('id', $id)->update($update);
                    $success[] = ['id' => $id, 'title' => $title, 'status' => $rule['to']];
                }
                Db::commit();
            } catch (\Exception $e) {
                Db::rollback();
                throw $e;
            }

            $data = ['success' => $success, 'failed' => $failed];
            if (!$success) {
                return json([
                    'code'    => 400,
                    'message' => '没有可操作的' . $this->actionText($action) . '内容',
                    'data'    => $data,
                ]);
            }

            $msg = '已' . $this->actionText($action) . ' ' . count($success) . ' 条';
            if ($failed) {
                $msg .= '，' . count($failed) . ' 条未处理';
            }
            return $this->ok($data, $msg);
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 批量操作名称 */
    private function actionText(string $action): string
    {
        return [
            'offline' => '下架',
            'approve' => '上架',
            'submit'  => '提交审核',
            'delete'  => '删除',
        ][$action] ?? '处理';
    }

    /** 草稿箱列表（含字数） */
    public function drafts(Request $request): Response
    {
        try {
            $uid = $this->uid($request);
            if ($uid === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }
            [$page, $limit] = $this->paging($request);

            $rows = Db::name('articles')->where('user_id', $uid)->where('status', 'draft')
                ->order('update_time', 'desc')
                ->paginate(['list_rows' => $limit, 'page' => $page]);

            $list = [];
            foreach ($rows->items() as $r) {
                $plain = preg_replace('/\s+/u', '', (string) ($r['content'] ?? '')) ?? '';
                $list[] = [
                    'id'        => $r['id'],
                    'title'     => (string) ($r['title'] ?? ''),
                    'type'      => $r['type'],
                    'typeText'  => $r['type'] === 'video' ? '视频' : '图文',
                    'words'     => mb_strlen($plain),
                    'updatedAt' => (string) ($r['update_time'] ?? ''),
                ];
            }

            return $this->ok(['list' => $list, 'total' => $rows->total(), 'page' => $page, 'limit' => $limit]);
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 内容分类字典（编辑器分类下拉） */
    public function categories(): Response
    {
        try {
            $names = Db::name('article_categories')->where('status', 1)
                ->order('sort', 'asc')->column('name');

            return $this->ok(array_values($names));
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /**
     * 上传视频（我的视频）
     * 表单字段：file
     */
    public function uploadVideo(Request $request): Response
    {
        try {
            if ($this->uid($request) === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $file = $request->file('file');
            if (!$file) {
                return json(['code' => 400, 'message' => '未上传文件']);
            }

            $ext = strtolower((string) $file->getOriginalExtension());
            $allow = ['mp4', 'mov', 'avi', 'mkv', 'webm', 'm4v'];
            if (!in_array($ext, $allow, true)) {
                return json(['code' => 400, 'message' => '仅支持 ' . implode('/', $allow) . ' 格式']);
            }
            $maxMb = (int) $request->param('max_mb', 200);
            if ($file->getSize() > $maxMb * 1024 * 1024) {
                return json(['code' => 400, 'message' => "视频大小不能超过{$maxMb}MB"]);
            }

            $savePath = '/static/videos/article/';
            $fullPath = public_path() . $savePath;
            if (!is_dir($fullPath)) {
                mkdir($fullPath, 0755, true);
            }

            $filename = uniqid('video_') . '.' . $ext;
            $file->move($fullPath, $filename);

            return $this->ok([
                'url'      => $savePath . $filename,
                'size'     => $file->getSize(),
                'duration' => max(0, (int) $request->param('duration', 0)),
            ], '上传成功');
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /**
     * 上传图片（编辑器内嵌图片 / 手动设置封面）
     * 表单字段：file
     */
    public function uploadImage(Request $request): Response
    {
        try {
            if ($this->uid($request) === '') {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $file = $request->file('file');
            if (!$file) {
                return json(['code' => 400, 'message' => '未上传文件']);
            }

            $ext = strtolower((string) $file->getOriginalExtension());
            $allow = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (!in_array($ext, $allow, true)) {
                return json(['code' => 400, 'message' => '仅支持 ' . implode('/', $allow) . ' 格式']);
            }
            if ($file->getSize() > 10 * 1024 * 1024) {
                return json(['code' => 400, 'message' => '图片大小不能超过10MB']);
            }

            $savePath = '/static/images/article/';
            $fullPath = public_path() . $savePath;
            if (!is_dir($fullPath)) {
                mkdir($fullPath, 0755, true);
            }

            $filename = uniqid('img_') . '.' . $ext;
            $file->move($fullPath, $filename);

            return $this->ok(['url' => $savePath . $filename], '上传成功');
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    // ========================================================
    // 管理端（JwtAuth + AdminAuth）
    // ========================================================

    /** 管理端内容列表（全部创作者内容） */
    public function adminList(Request $request): Response
    {
        try {
            $type    = trim((string) $request->param('type', ''));
            $status  = trim((string) $request->param('status', ''));
            $keyword = trim((string) $request->param('keyword', ''));
            [$page, $limit] = $this->paging($request);

            $where = [];
            if (in_array($type, self::TYPES, true)) {
                $where[] = ['type', '=', $type];
            }
            if (isset(self::STATUS_TEXT[$status])) {
                $where[] = ['status', '=', $status];
            }
            if ($keyword !== '') {
                $where[] = ['title', 'like', "%{$keyword}%"];
            }

            $rows = Db::name('articles')->where($where)
                ->order('update_time', 'desc')
                ->paginate(['list_rows' => $limit, 'page' => $page]);

            $list = [];
            $items = $rows->items();
            // 批量取作者信息，避免 N+1 查询
            $userIds = array_values(array_unique(array_column($items, 'user_id')));
            $authors = [];
            if ($userIds !== []) {
                $authors = Db::name('users')->whereIn('id', $userIds)
                    ->column('nickname, avatar', 'id');
            }
            foreach ($items as $r) {
                $item = $this->formatItem($r);
                $item['author']       = $authors[$r['user_id']]['nickname'] ?? '';
                $item['authorAvatar'] = $authors[$r['user_id']]['avatar'] ?? '';
                $list[] = $item;
            }

            return $this->ok(['list' => $list, 'total' => $rows->total(), 'page' => $page, 'limit' => $limit]);
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    /** 管理端审核：action=approve|reject，reject 需 reason */
    public function review(Request $request, $id): Response
    {
        try {
            $action = trim((string) $request->param('action', ''));
            $reason = trim((string) $request->param('reason', ''));

            if (!in_array($action, ['approve', 'reject'], true)) {
                return json(['code' => 400, 'message' => '审核动作不正确']);
            }
            $row = Db::name('articles')->where('id', $id)->find();
            if (!$row) {
                return json(['code' => 404, 'message' => '内容不存在']);
            }
            if ($row['status'] !== 'pending') {
                return json(['code' => 400, 'message' => '仅待审核内容可执行审核']);
            }
            if ($action === 'reject' && $reason === '') {
                return json(['code' => 400, 'message' => '驳回原因不能为空']);
            }

            Db::name('articles')->where('id', $id)->update([
                'status'        => $action === 'approve' ? 'approved' : 'rejected',
                'audit_time'    => date('Y-m-d H:i:s'),
                'reject_reason' => $action === 'reject' ? $reason : null,
                'update_time'   => date('Y-m-d H:i:s'),
            ]);

            return $this->ok(null, $action === 'approve' ? '已通过' : '已驳回');
        } catch (\Exception $e) {
            return $this->err($e);
        }
    }

    // ========================================================
    // 内部方法
    // ========================================================

    /** 当前登录用户ID */
    private function uid(Request $request): string
    {
        return (string) ($request->userId ?? '');
    }

    /** 分页参数 [page, limit]（limit 上限 50） */
    private function paging(Request $request): array
    {
        $page  = max(1, (int) $request->param('page', 1));
        $limit = min(50, max(1, (int) $request->param('limit', 10)));
        return [$page, $limit];
    }

    /** 统一成功响应 */
    private function ok($data = null, string $message = '获取成功'): Response
    {
        return json(['code' => 200, 'message' => $message, 'data' => $data]);
    }

    /** 统一异常响应 */
    private function err(\Exception $e): Response
    {
        return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
    }

    /** 读取并校验内容表单；校验失败返回 ['__error' => 原因] */
    private function readForm(Request $request): array
    {
        $type = trim((string) $request->param('type', 'image_text'));
        if (!in_array($type, self::TYPES, true)) {
            return ['__error' => '内容类型不正确'];
        }

        $title = trim((string) $request->param('title', ''));
        if ($title === '') {
            return ['__error' => '标题不能为空'];
        }
        if (mb_strlen($title) > 60) {
            return ['__error' => '标题不能超过60个字符'];
        }

        $content = (string) $request->param('content', '');
        if (trim($content) === '') {
            return ['__error' => '正文不能为空'];
        }

        $isPaid = (int) $request->param('is_paid', 0) === 1 ? 1 : 0;
        $price  = round((float) $request->param('price', 0), 2);
        if ($isPaid === 1 && $price <= 0) {
            return ['__error' => '付费内容需填写有效的付费金额'];
        }

        $tags = $request->param('tags', []);
        if (is_string($tags)) {
            $tags = explode(',', $tags);
        }
        $tags = array_values(array_filter(array_map(
            static fn($t) => trim((string) $t),
            is_array($tags) ? $tags : []
        )));
        if (count($tags) > 10) {
            return ['__error' => '标签最多10个'];
        }

        // 摘要未填时由后端从正文自动提取
        $summary = trim((string) $request->param('summary', ''));
        if ($summary === '') {
            $plain = preg_replace('/[#*`>\-\[\]()!_]/u', '', $content) ?? '';
            $plain = preg_replace('/\s+/u', ' ', $plain) ?? '';
            $summary = mb_substr(trim($plain), 0, 100);
        }

        return [
            'type'      => $type,
            'title'     => $title,
            'content'   => $content,
            'summary'   => $summary,
            'category'  => mb_substr(trim((string) $request->param('category', '')), 0, 50),
            'tags'      => mb_substr(implode(',', $tags), 0, 255),
            'is_paid'   => $isPaid,
            'price'     => $isPaid === 1 ? $price : 0.00,
            'cover'     => mb_substr(trim((string) $request->param('cover', '')), 0, 500),
            'video_url' => mb_substr(trim((string) $request->param('video_url', '')), 0, 500),
            'duration'  => max(0, (int) $request->param('duration', 0)),
        ];
    }

    /** 统一输出格式（camelCase，对齐 Post::formatPost 约定） */
    private function formatItem(array $r): array
    {
        $status = (string) ($r['status'] ?? 'draft');
        return [
            'id'           => $r['id'],
            'type'         => $r['type'],
            'typeText'     => $r['type'] === 'video' ? '视频' : '图文',
            'title'        => (string) ($r['title'] ?? ''),
            'summary'      => (string) ($r['summary'] ?? ''),
            'cover'        => (string) ($r['cover'] ?? ''),
            'category'     => (string) ($r['category'] ?? ''),
            'tags'         => array_values(array_filter(explode(',', (string) ($r['tags'] ?? '')))),
            'isPaid'       => (int) ($r['is_paid'] ?? 0) === 1,
            'price'        => (float) ($r['price'] ?? 0),
            'status'       => $status,
            'statusText'   => self::STATUS_TEXT[$status] ?? $status,
            'rejectReason' => (string) ($r['reject_reason'] ?? ''),
            'views'        => (int) ($r['views'] ?? 0),
            'likes'        => (int) ($r['likes'] ?? 0),
            'comments'     => (int) ($r['comments'] ?? 0),
            'fans'         => (int) ($r['fans'] ?? 0),
            'duration'     => (int) ($r['duration'] ?? 0),
            'submitTime'   => (string) ($r['submit_time'] ?? ''),
            'createdAt'    => (string) ($r['create_time'] ?? ''),
            'updatedAt'    => (string) ($r['update_time'] ?? ''),
        ];
    }
}
