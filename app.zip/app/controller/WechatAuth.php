<?php
declare(strict_types=1);

namespace app\controller;

use app\BaseController;
use think\Request;
use think\facade\Db;
use think\facade\Cache;
use think\Response;
use app\service\JwtService;
use app\service\VpConfig;
use app\service\VirtualPayService;

class WechatAuth extends BaseController
{
    /**
     * 微信登录 - 通过code获取openid
     */
    public function login(Request $request): Response
    {
        try {
            $code = $request->param('code', '');
            
            if (empty($code)) {
                return json(['code' => 400, 'message' => 'code不能为空']);
            }
            
            // 通过code获取openid
            $openid = $this->getOpenidByCode($code);
            
            if (!$openid) {
                return json(['code' => 400, 'message' => '获取openid失败']);
            }
            
            // 检查用户是否存在 - 使用统一的 users 表
            $user = Db::name('users')->where('openid', $openid)->find();
            
            if ($user) {
                // 老用户登录
                $token = $this->generateToken($user['id']);
                $this->updateUserToken($user['id'], $token);
                
                return json([
                    'code' => 200,
                    'message' => '登录成功',
                    'data' => [
                        'token' => $token,
                        'is_new_user' => false,
                        'user_info' => [
                            'id' => $user['id'],
                            'openid' => $user['openid'],
                            'nickname' => $user['nickname'],
                            'avatar' => $user['avatar'],
                            'visit_count' => $user['visit_count'],
                            'like_count' => $user['like_count'],
                            'user_type' => $user['user_type']
                        ]
                    ]
                ]);
            } else {
                // 新用户，需要获取微信信息
                $token = $this->generateToken(0); // 临时token
                
                return json([
                    'code' => 201,
                    'message' => '新用户，需要完善信息',
                    'data' => [
                        'token' => $token,
                        'is_new_user' => true,
                        'openid' => $openid
                    ]
                ]);
            }
            
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }
    
    /**
     * 完善用户信息 - 新用户填写头像昵称
     */
    public function completeUserInfo(Request $request): Response
    {
        try {
            $data = $request->only([
                'openid', 'nickName', 'avatarUrl', 'gender', 'country', 
                'province', 'city', 'language'
            ]);
            
            if (empty($data['openid']) || empty($data['nickName']) || empty($data['avatarUrl'])) {
                return json(['code' => 400, 'message' => 'openid、昵称和头像不能为空']);
            }
            
            // 检查是否已存在 - 使用统一的 users 表
            $existingUser = Db::name('users')->where('openid', $data['openid'])->find();
            
            if ($existingUser) {
                return json(['code' => 400, 'message' => '用户已存在']);
            }
            
            // 默认注册角色（全局仅一个，启用状态）：新注册用户自动获得
            $defaultRoleId = (int) Db::name('roles')
                ->where('is_default', 1)
                ->where('status', 1)
                ->value('id');

            // 创建新用户 - 使用统一的 users 表
            // 真实昵称/头像进「待审快照」，users 先写占位，审核通过后才对外生效（资料审核）
            $insertData = [
                'openid' => $data['openid'],
                'nickname' => '微信用户' . substr(md5($data['openid']), 0, 8), // 占位，保证唯一
                'avatar' => '/static/images/default-avatar.jpg',
                'gender' => $data['gender'] ?? 0,
                'country' => $data['country'] ?? '',
                'province' => $data['province'] ?? '',
                'city' => $data['city'] ?? '',
                'language' => $data['language'] ?? 'zh_CN',
                'code_age' => 0,
                'visit_count' => 0,
                'like_count' => 0,
                'user_type' => 'visitor', // 枚举值：visitor/customer/webmaster
                'status' => 1,
                'role_id' => $defaultRoleId, // 默认注册角色（主角色，兼容旧逻辑）
                'profile_status' => 'pending', // 资料待审
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
                'last_login_time' => date('Y-m-d H:i:s')
            ];
            
            // users.id 为显式 UUID（非自增），不能用 insertGetId（会返回错误的 lastInsertId）
            $userId = uuid();
            Db::name('users')->insert(array_merge(['id' => $userId], $insertData));

            // 写入默认角色关联（多角色兼容）
            if ($defaultRoleId > 0) {
                Db::name('user_roles')->insert([
                    'id'          => uuid(),
                    'user_id'     => $userId,
                    'role_id'     => $defaultRoleId,
                    'create_time' => date('Y-m-d H:i:s')
                ]);
            }

            // 初始化用户钱包（金币余额，默认 0）
            Db::name('user_wallet')->insert([
                'id'           => uuid(),
                'user_id'      => $userId,
                'balance'      => 0,
                'frozen'       => 0,
                'total_earned' => 0,
                'total_spent'  => 0,
                'create_time'  => date('Y-m-d H:i:s'),
                'update_time'  => date('Y-m-d H:i:s')
            ]);

            // 真实资料写入待审快照（审核通过后才覆盖 users，资料审核）
            Db::name('user_profile_pending')->insert([
                'id'          => uuid(),
                'user_id'     => $userId,
                'nickname'    => $data['nickName'],
                'avatar'      => $data['avatarUrl'],
                'gender'      => $data['gender'] ?? 0,
                'country'     => $data['country'] ?? '',
                'province'    => $data['province'] ?? '',
                'city'        => $data['city'] ?? '',
                'status'      => 'pending',
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ]);

            // 生成正式token
            $token = $this->generateToken($userId);
            $this->updateUserToken($userId, $token);
            
            return json([
                'code' => 200,
                'message' => '用户信息完善成功',
                'data' => [
                    'token' => $token,
                    'user_info' => [
                        'id' => $userId,
                        'openid' => $data['openid'],
                        'nickname' => $data['nickName'],
                        'avatar' => $data['avatarUrl'],
                        'visit_count' => 0,
                        'like_count' => 0,
                        'user_type' => 'visitor'
                    ]
                ]
            ]);
            
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }
    
    /**
     * 通过code获取openid
     */
    private function getOpenidByCode($code)
    {
        $url = "https://api.weixin.qq.com/sns/jscode2session";
        $params = [
            'appid' => VpConfig::get('VP_APPID', 'wx63617f985d8c028c'),
            'secret' => VpConfig::get('VP_APP_SECRET', 'a0a3d18cc49c5f70174245bf5e79d558'),
            'js_code' => $code,
            'grant_type' => 'authorization_code'
        ];
        
        $url .= '?' . http_build_query($params);
        
        $response = file_get_contents($url);
        $data = json_decode($response, true);
        
        if (isset($data['openid'])) {
            return $data['openid'];
        }
        
        return false;
    }
    
    /**
     * 生成JWT token
     */
    private function generateToken($userId)
    {
        $jwtService = new JwtService();
        $payload = [
            'user_id' => $userId,
            'type' => 'user'
        ];
        
        return $jwtService->generateToken($payload);
    }
    
    /**
     * 更新用户token
     */
    private function updateUserToken($userId, $token)
    {
        $expireTime = date('Y-m-d H:i:s', time() + (7 * 24 * 60 * 60));
        
        Db::name('users') // 使用统一的 users 表
            ->where('id', $userId)
            ->update([
                'token' => $token,
                'token_expire_time' => $expireTime,
                'last_login_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ]);
    }
    
    /**
     * 验证token
     */
    public function verifyToken(Request $request): Response
    {
        try {
            $token = $request->header('Authorization');
            
            if (!$token) {
                return json(['code' => 401, 'message' => 'token不能为空']);
            }
            
            // 移除Bearer前缀
            $token = str_replace('Bearer ', '', $token);
            
            $jwtService = new JwtService();
            $payload = $jwtService->verifyToken($token);
            
            if (!$payload) {
                return json(['code' => 401, 'message' => 'token无效']);
            }
            
            // 检查token是否过期
            if (isset($payload->exp) && $payload->exp < time()) {
                return json(['code' => 401, 'message' => 'token已过期']);
            }
            
            // 获取用户信息 - 使用统一的 users 表
            $user = Db::name('users')->where('id', $payload->user_id)->find();
            
            if (!$user) {
                return json(['code' => 404, 'message' => '用户不存在']);
            }
            
            return json([
                'code' => 200,
                'message' => 'token有效',
                'data' => [
                    'user_id' => $user['id'],
                    'openid' => $user['openid'],
                    'nickname' => $user['nickname'],
                    'avatar' => $user['avatar'],
                    'visit_count' => $user['visit_count'],
                    'like_count' => $user['like_count'],
                    'user_type' => $user['user_type']
                ]
            ]);
            
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }


    /**
     * 小程序端确认登录（需用户 JWT；启用账号即可）
     */
    public function scanConfirm(Request $request): Response
    {
        try {
            $userId = $request->userId ?? '';
            $ticket = (string) $request->param('ticket', '');

            if (empty($userId)) {
                return json(['code' => 401, 'message' => '请先登录小程序']);
            }
            $row = Db::name('admin_scan_tickets')
                ->where('ticket', $ticket)
                ->where('status', 0)
                ->find();
            if (!$row) {
                return json(['code' => 404, 'message' => '票据不存在或已使用']);
            }
            if (strtotime($row['expire_time']) < time()) {
                return json(['code' => 410, 'message' => '二维码已过期']);
            }

            $user = Db::name('users')->where('id', $userId)->find();
            if (!$user) {
                return json(['code' => 404, 'message' => '用户不存在']);
            }
            if ($user['status'] != 1) {
                return json(['code' => 403, 'message' => '账号已被禁用']);
            }

            Db::name('admin_scan_tickets')
                ->where('ticket', $ticket)
                ->update(['status' => 1, 'user_id' => $userId]);

            return json(['code' => 200, 'message' => '已确认，请在网页端完成登录']);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 账号密码登录（非小程序端：H5 / App）
     * 支持 手机号 / 用户名 / 邮箱 登录，密码走 bcrypt 校验。
     * 返回结构与微信登录一致：{ token, user_info }，前端 finishLogin 可直接复用。
     */
    public function passwordLogin(Request $request): Response
    {
        try {
            $account  = trim((string) $request->param('account', ''));
            $password = (string) $request->param('password', '');

            if ($account === '' || $password === '') {
                return json(['code' => 400, 'message' => '请输入账号和密码']);
            }

            // 图形验证码校验（防爆破）：一次性、5 分钟过期，错误即失效
            $captchaId = (string) $request->param('captchaId', '');
            $captcha   = (string) $request->param('captcha', '');
            if ($captchaId === '' || $captcha === '') {
                return json(['code' => 400, 'message' => '请输入验证码']);
            }
            $cached = Cache::get('wechat_captcha_' . $captchaId);
            if (!$cached || strtolower($captcha) !== strtolower((string) $cached)) {
                Cache::delete('wechat_captcha_' . $captchaId);
                return json(['code' => 400, 'message' => '验证码错误']);
            }
            Cache::delete('wechat_captcha_' . $captchaId);

            // 手机号 / 用户名 / 邮箱 任一匹配，且账号启用、已设置密码
            $user = Db::name('users')
                ->where('phone', $account)
                ->where('status', 1)
                ->field('id, openid, nickname, avatar, user_type, visit_count, like_count, password')
                ->find();

            if (!$user || empty($user['password']) || !password_verify($password, $user['password'])) {
                return json(['code' => 401, 'message' => '账号或密码错误']);
            }

            $token = $this->generateToken($user['id']);
            $this->updateUserToken($user['id'], $token);

            return json([
                'code'    => 200,
                'message' => '登录成功',
                'data'    => [
                    'token'     => $token,
                    'user_info' => [
                        'id'          => $user['id'],
                        'openid'      => $user['openid'],
                        'nickname'    => $user['nickname'],
                        'avatar'      => $user['avatar'],
                        'visit_count' => $user['visit_count'],
                        'like_count'  => $user['like_count'],
                        'user_type'   => $user['user_type'],
                    ],
                ],
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 获取登录图形验证码：返回 captchaId + base64 图片
     * 与后台 AdminAuth::captcha 同款，缓存键 wechat_captcha_{id}，5 分钟有效，登录成功后一次性删除
     */
    public function captcha(): Response
    {
        try {
            $code = $this->genCaptchaCode(4);
            $id   = bin2hex(random_bytes(8));
            Cache::set('wechat_captcha_' . $id, strtolower($code), 300);
            $img  = $this->renderCaptchaImage($code);
            return json([
                'code'    => 200,
                'message' => '获取成功',
                'data'    => [
                    'captchaId' => $id,
                    'image'     => 'data:image/png;base64,' . base64_encode($img),
                ],
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 生成验证码字符（去掉易混淆的 0/O/1/l/I）
     */
    private function genCaptchaCode(int $len): string
    {
        $pool = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $max  = strlen($pool) - 1;
        $out  = '';
        for ($i = 0; $i < $len; $i++) {
            $out .= $pool[rand(0, $max)];
        }
        return $out;
    }

    /**
     * 用 GD 内置字体绘制验证码图片（不依赖外部 TTF 字体文件）
     */
    private function renderCaptchaImage(string $code): string
    {
        if (!extension_loaded('gd')) {
            throw new \RuntimeException('GD extension not available');
        }
        $w = 110;
        $h = 40;
        $img = imagecreatetruecolor($w, $h);
        $bg  = imagecolorallocate($img, 245, 247, 250);
        imagefill($img, 0, 0, $bg);

        for ($i = 0; $i < 6; $i++) {
            $c = imagecolorallocate($img, rand(180, 225), rand(180, 225), rand(180, 225));
            imageline($img, rand(0, $w), rand(0, $h), rand(0, $w), rand(0, $h), $c);
        }
        for ($i = 0; $i < 40; $i++) {
            $c = imagecolorallocate($img, rand(180, 225), rand(180, 225), rand(180, 225));
            imagesetpixel($img, rand(0, $w), rand(0, $h), $c);
        }
        $len = strlen($code);
        for ($i = 0; $i < $len; $i++) {
            $color = imagecolorallocate($img, rand(40, 120), rand(40, 120), rand(40, 160));
            $font  = rand(4, 5);
            $x = 12 + $i * (($w - 24) / $len);
            $y = rand(8, 16);
            imagestring($img, $font, (int) $x, $y, $code[$i], $color);
        }

        ob_start();
        imagepng($img);
        $data = ob_get_contents();
        ob_end_clean();
        imagedestroy($img);
        return $data;
    }

}
