<?php
declare(strict_types=1);

namespace app\controller;

use app\BaseController;
use think\Request;
use think\facade\Db;
use think\Response;
use app\model\User as UserModel;

class User extends BaseController
{
	public function index(){
		return json(['code' => 200, 'message' => '用户管理接口']);
	}
    /**
     * 获取用户公开资料（单个）
     * 仅返回主页需要的字段：基础资料 + 封面 + 认证 + 文章，
     * 剔除 token、邮箱、手机、社交账号等敏感/无用字段。
     */
    public function info(Request $request): Response
    {
        try {
            $id = $request->param('id', '');
            if (empty($id)) {
                return json(['code' => 400, 'message' => '缺少用户ID']);
            }
            $user = Db::name('users')->where('id', $id)->find();
            if (!$user) {
                return json(['code' => 404, 'message' => '用户信息不存在']);
            }

            // 公开资料白名单（不返回 token / email / phone / qq / wechat / openid 等）
            $basic = [
                'id'          => $user['id'],
                'nickname'    => $user['nickname'] ?? '',
                'avatar'      => $user['avatar'] ?? '',
                'gender'      => $user['gender'] ?? 0,
                'code_age'    => $user['code_age'] ?? '',
                'address'     => $user['address'] ?? '',
                'user_type'   => $user['user_type'] ?? '',
                'role'        => $user['role'] ?? '',
                'status'      => $user['status'] ?? 0,
                'visit_count' => $user['visit_count'] ?? 0,
                'like_count'  => $user['like_count'] ?? 0,
                'github'      => $user['github'] ?? '',
                'web_url'     => $user['web_url'] ?? '',
                'create_time' => $user['create_time'] ?? '',
            ];

            // 封面：取该用户最新一条「已通过」的封面（待审/驳回不对外）
            $cover = Db::name('user_covers')
                ->where('user_id', $id)
                ->where('status', 'approved')
                ->order('create_time', 'desc')
                ->field('image, status, create_time')
                ->find();

            // 认证：取最新一条认证记录
            $cert = Db::name('user_certifications')
                ->where('user_id', $id)
                ->order('create_time', 'desc')
                ->field('type, status')
                ->find();
            $certification = $cert
                ? ['type' => $cert['type'], 'status' => $cert['status']]
                : ['type' => '', 'status' => 'none'];

            // 文章：该用户已发布帖子（最新 10 条 + 总数），直接拼装为前端 PostCard 所需结构
            $rawArticles = Db::name('forum_posts')
                ->where('user_id', $id)
                ->where('status', 1)
                ->order('create_time', 'desc')
                ->limit(10)
                ->field('id, title, summary, cover_images, tags, category, like_count, comment_count, views, create_time')
                ->select()
                ->toArray();
            $articleList = array_map(function ($a) use ($user, $id) {
                $images = $a['cover_images'] ?? '';
                if (is_string($images)) {
                    $images = json_decode($images, true) ?: [];
                }
                if (!is_array($images)) {
                    $images = [];
                }
                $tags = $a['tags'] ?? '';
                if (is_string($tags)) {
                    $tags = json_decode($tags, true) ?: [];
                }
                if (!is_array($tags)) {
                    $tags = [];
                }
                return [
                    'id'           => $a['id'],
                    'title'        => $a['title'] ?? '',
                    'summary'      => $a['summary'] ?? '',
                    'author'       => $user['nickname'] ?? '',
                    'authorAvatar' => $user['avatar'] ?? '',
                    'userId'       => $a['user_id'] ?? $id,
                    'category'     => $a['category'] ?? 'other',
                    'tags'         => $tags,
                    'createdAt'    => $a['create_time'] ?? '',
                    'views'        => (int)($a['views'] ?? 0),
                    'comments'     => (int)($a['comment_count'] ?? 0),
                    'likes'        => (int)($a['like_count'] ?? 0),
                    'isEssence'    => false,
                    'type'         => 'blog',
                    'coverImages'  => array_slice($images, 0, 9),
                    ];
            }, $rawArticles);
            $articleTotal = Db::name('forum_posts')
                ->where('user_id', $id)
                ->where('status', 1)
                ->count();

            return json([
                'code'    => 200,
                'message' => '获取成功',
                'data'    => array_merge($basic, [
                    'cover'         => $cover ?: null,
                    'certification' => $certification,
                    'articles'      => [
                        'total' => $articleTotal,
                        'list'  => $articleList,
                    ],
                ])
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 获取用户列表（支持筛选、分页、搜索）
     * 更新：使用统一的 users 表
     */
    public function list(Request $request): Response
    {
        try {
            $keyword = $request->param('keyword', '');
            $roleId = $request->param('role_id', '');
            $status = $request->param('status', '');
            $userType = $request->param('user_type', '');
            $page = $request->param('page', 1);
            $limit = $request->param('limit', 10);

            $where = [];
            if ($keyword) {
                $where[] = ['nickname', 'like', "%$keyword%"];
            }
            // 按角色筛选：拥有该角色（user_roles 关联 或 主角色 role_id）的用户
            if ($roleId !== '' && $roleId !== '全部' && $roleId !== '0') {
                $idsByPivot = Db::name('user_roles')->where('role_id', $roleId)->column('user_id');
                $idsByMain  = Db::name('users')->where('role_id', $roleId)->column('id');
                $matched = array_values(array_unique(array_merge($idsByPivot, $idsByMain)));
                $where[] = ['id', 'in', $matched];
            }
            if ($status && $status !== '全部状态') {
                $where[] = ['status', '=', $status === '活跃' ? 1 : 0];
            }
            if ($userType && $userType !== '全部类型') {
                $where[] = ['user_type', '=', $userType];
            }

            $users = Db::name('users')->where($where)
                ->order('id', 'desc')
                ->paginate([
                    'list_rows' => $limit,
                    'page' => $page
                ]);

            $list = $users->items();

            // 批量读取每个用户的角色（多角色）
            $roleMap = [];
            $userIds = array_column($list, 'id');
            if ($userIds) {
                $roleRows = Db::name('user_roles')->alias('ur')
                    ->leftJoin('roles r', 'r.id = ur.role_id')
                    ->where('ur.user_id', 'in', $userIds)
                    ->where('r.status', 1)
                    ->field('ur.user_id, r.id as rid, r.name, r.code')
                    ->select()
                    ->toArray();
                foreach ($roleRows as $rr) {
                    $roleMap[$rr['user_id']][] = [
                        'id'   => $rr['rid'],
                        'name' => $rr['name'],
                        'code' => $rr['code']
                    ];
                }
            }
            foreach ($list as &$u) {
                $u['role_list'] = $roleMap[$u['id']] ?? [];
                $u['role_ids']  = array_column($u['role_list'], 'id');
            }
            unset($u);

            return json([
                'code' => 200,
                'message' => '获取成功',
                'data' => [
                    'list' => $list,
                    'total' => $users->total(),
                    'page' => $page,
                    'limit' => $limit
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 新增用户（管理员手动创建）
     * 更新：使用统一的 users 表
     */
    public function create(Request $request): Response
    {
        try {
            $data = $request->only(['nickname', 'role_id', 'status', 'avatar', 'cover', 'welcome_text', 'email', 'phone', 'qq', 'wechat', 'github', 'weibo', 'douyin', 'web_url', 'user_type', 'password']);
            if (empty($data['nickname'])) {
                return json(['code' => 400, 'message' => '昵称不能为空']);
            }

            // 多角色：优先 role_ids，兼容单 role_id
            $roleIds = $this->parseRoleIds($request);

            // 密码：仅在传入时哈希写入（不传则保持原值/空）
            if (!empty($data['password'])) {
                $data['password'] = \app\model\User::hashPassword($data['password']);
            } else {
                unset($data['password']);
            }

            $data['user_type'] = $data['user_type'] ?? 'admin';
            $data['status'] = $data['status'] ?? 1;
            $data['create_time'] = date('Y-m-d H:i:s');
            $data['update_time'] = date('Y-m-d H:i:s');
            // 修正 status 字段为 1/0
            if (isset($data['status'])) {
                if ($data['status'] === 'active') {
                    $data['status'] = 1;
                } elseif ($data['status'] === 'inactive') {
                    $data['status'] = 0;
                }
            }
            $data['avatar'] = $data['avatar'] ?? '/static/images/default-avatar.jpg';
            // 主角色（兼容旧逻辑 / 菜单 / 登录）
            $data['role_id'] = !empty($roleIds) ? (int) $roleIds[0] : 0;

            $id = uuid();
            Db::name('users')->insert(array_merge(['id' => $id], $data));
            $this->syncUserRoles($id, $roleIds ?? []);

            return json(['code' => 200, 'message' => '添加成功', 'data' => ['id' => $id]]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }


    /**
     * 删除用户
     */
    public function delete(Request $request): Response
    {
        try {
            $id = $request->param('id', 0);
            if (empty($id)) {
                return json(['code' => 400, 'message' => '缺少用户ID']);
            }
            Db::name('user_roles')->where('user_id', $id)->delete();
            $result = Db::name('users')->where('id', $id)->delete();
            if ($result) {
                return json(['code' => 200, 'message' => '删除成功']);
            } else {
                return json(['code' => 500, 'message' => '删除失败']);
            }
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 编辑用户（支持指定ID，兼容原有字段）
     * 更新：使用统一的 users 表，移除密码相关字段
     */
    public function update(Request $request): Response
    {
        try {
            $id = $request->param('id');
            $data = $request->only(['role_id', 'status', 'avatar', 'cover', 'welcome_text', 'nickname', 'code_age' ,'email', 'phone', 'qq', 'wechat', 'github', 'weibo', 'douyin', 'web_url', 'working_hours', 'password']);
            if (!empty($data['password'])) {
                $data['password'] = \app\model\User::hashPassword($data['password']);
            } else {
                unset($data['password']);
            }
            if (isset($data['status'])) {
                if ($data['status'] === 'active') {
                    $data['status'] = 1;
                } elseif ($data['status'] === 'inactive') {
                    $data['status'] = 0;
                }
            }

            // 多角色同步（未传角色参数则不改动）
            $roleIds = $this->parseRoleIds($request);
            if ($roleIds !== null) {
                unset($data['role_id']);
                $data['role_id'] = !empty($roleIds) ? (int) $roleIds[0] : 0;
            } else {
                unset($data['role_id']);
            }

            $data['update_time'] = date('Y-m-d H:i:s');
            $result = Db::name('users')->where('id', $id)->update($data);
            if ($roleIds !== null) {
                $this->syncUserRoles($id, $roleIds);
            }
            if ($result !== false) {
                return json(['code' => 200, 'message' => '更新成功']);
            } else {
                return json(['code' => 500, 'message' => '更新失败']);
            }
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 获取启动页数据（头像 + 欢迎语）
     */
    public function getSplashData(): Response
    {
        try {
            // 获取站点主理人(webmaster)的头像作为启动页头像；无 webmaster 时回退默认值
            $user = Db::name('users')->where('user_type', 'webmaster')->field('avatar, nickname')->find();
            $avatar = $user['avatar'] ?? '/static/images/peter.jpg';
			$nickname = $user['nickname'] ?? 'Sam';
            
            // 获取系统设置中的 subdescription
            $setting = Db::name('system_settings')
                ->where('setting_key', 'subdescription')
                ->field('setting_value')
                ->find();
            $welcomeText = $setting['setting_value'] ?? '乔布斯于科技世界种下创新种子，罗永浩在行业浪潮里坚守情怀高地，都让我着迷。我仿佛看到老罗和乔布斯在科技和人文的十字路口探讨人生，所以我带着这份情怀，期待在这里与你相遇。';
            
            return json([
                'code' => 200,
                'message' => '获取成功',
                'data' => [
					'nickname' => $nickname,
                    'avatar' => $avatar,
                    'welcome_text' => $welcomeText
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 获取地图数据
     */
    public function mapData(): Response
    {
        try {
            $mapData = [
                ['name' => '北京', 'value' => 100, 'level' => '核心服务区'],
                ['name' => '上海', 'value' => 95, 'level' => '一般服务区'],
                ['name' => '广东', 'value' => 90, 'level' => '一般服务区'],
                ['name' => '江苏', 'value' => 85, 'level' => '核心服务区'],
                ['name' => '浙江', 'value' => 80, 'level' => '一般服务区'],
                ['name' => '山东', 'value' => 75, 'level' => '核心服务区'],
                ['name' => '四川', 'value' => 70, 'level' => '一般服务区'],
                ['name' => '湖北', 'value' => 65, 'level' => '一般服务区'],
                ['name' => '河南', 'value' => 60, 'level' => '核心服务区'],
                ['name' => '湖南', 'value' => 55, 'level' => '一般服务区'],
                ['name' => '福建', 'value' => 50, 'level' => '一般服务区'],
                ['name' => '安徽', 'value' => 45, 'level' => '一般服务区'],
                ['name' => '河北', 'value' => 40, 'level' => '一般服务区'],
                ['name' => '陕西', 'value' => 35, 'level' => '一般服务区'],
                ['name' => '江西', 'value' => 30, 'level' => '待开发区域'],
                ['name' => '重庆', 'value' => 25, 'level' => '待开发区域'],
                ['name' => '天津', 'value' => 20, 'level' => '待开发区域'],
                ['name' => '云南', 'value' => 15, 'level' => '待开发区域'],
                ['name' => '广西壮族自治区', 'value' => 10, 'level' => '待开发区域'],
                ['name' => '山西', 'value' => 5, 'level' => '待开发区域']
            ];
            
            return json([
                'code' => 200,
                'message' => '获取成功',
                'data' => $mapData
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 上传用户头像
     */
    public function uploadAvatar(Request $request): Response
    {
        try {
            $file = $request->file('avatar');
            if (!$file) {
                return json(['code' => 400, 'message' => '未上传文件']);
            }
            $savePath = '/static/images/avatar/';
            $ext = $file->getOriginalExtension();
            $filename = uniqid('avatar_') . '.' . $ext;
            $file->move(public_path() . $savePath, $filename);
            $url = $savePath . $filename;
            return json(['code' => 200, 'message' => '上传成功', 'data' => ['url' => $url]]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 上传用户封面（需登录）
     * 文件保存后写入 user_covers 表，状态默认为 pending（待审核），审核通过后才生效
     */
    public function uploadCover(Request $request): Response
    {
        try {
            $userId = $request->userId ?? '';
            if (!$userId) {
                return json(['code' => 401, 'message' => '未登录或登录已过期']);
            }

            $file = $request->file('cover');
            if (!$file) {
                return json(['code' => 400, 'message' => '未上传文件']);
            }

            // 验证文件类型
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext = strtolower($file->getOriginalExtension());
            if (!in_array($ext, $allowedTypes)) {
                return json(['code' => 400, 'message' => '不支持的文件类型，仅支持：' . implode(', ', $allowedTypes)]);
            }

            // 验证文件大小（最大5MB）
            if ($file->getSize() > 5 * 1024 * 1024) {
                return json(['code' => 400, 'message' => '文件大小不能超过5MB']);
            }

            $savePath = '/static/images/cover/';
            $filename = uniqid('cover_') . '.' . $ext;

            // 确保目录存在
            $fullPath = public_path() . $savePath;
            if (!is_dir($fullPath)) {
                mkdir($fullPath, 0755, true);
            }

            $file->move($fullPath, $filename);

            $url = $savePath . $filename;

            // 写入封面表，状态默认 pending（待审核）
            $coverId = uuid();
            Db::name('user_covers')->insert([
                'id'          => $coverId,
                'user_id'     => $userId,
                'image'       => $url,
                'status'      => 'pending',
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ]);

            return json([
                'code'    => 200,
                'message' => '上传成功，封面待审核',
                'data'    => ['url' => $url, 'cover_id' => $coverId, 'status' => 'pending']
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }



    /**
     * 保存用户信息（小程序端编辑资料）
     * 资料字段进入「待审快照」，审核通过后才覆盖 users 对外生效（资料审核）。
     * 统计/登录类字段（visit_count/like_count/last_login_time）直接更新，不参与审核。
     */
    public function saveUserInfo(Request $request): Response
    {
        try {
            $data = $request->only([
                'nickName', 'avatarUrl', 'gender', 'country', 'province',
                'city', 'language', 'visitCount', 'likeCount', 'loginTime'
            ]);

            // 生成唯一用户ID（基于微信信息）
            $userKey = md5($data['nickName'] . $data['avatarUrl']);

            // 检查用户是否已存在 - 使用统一的 users 表
            $existingUser = Db::name('users')->where('user_key', $userKey)->find();

            if ($existingUser) {
                $userId = $existingUser['id'];

                // 统计/登录信息直接更新（非审核字段）
                Db::name('users')->where('id', $userId)->update([
                    'visit_count'      => $data['visitCount'] ?? $existingUser['visit_count'],
                    'like_count'       => $data['likeCount'] ?? $existingUser['like_count'],
                    'last_login_time'  => date('Y-m-d H:i:s'),
                    'update_time'      => date('Y-m-d H:i:s')
                ]);

                // 资料字段进入待审快照
                $pending = [
                    'nickname'    => $data['nickName'],
                    'avatar'      => $data['avatarUrl'],
                    'gender'      => $data['gender'] ?? 0,
                    'country'     => $data['country'] ?? '',
                    'province'    => $data['province'] ?? '',
                    'city'        => $data['city'] ?? '',
                    'status'      => 'pending',
                    'update_time' => date('Y-m-d H:i:s')
                ];
                $ex = Db::name('user_profile_pending')->where('user_id', $userId)->find();
                if ($ex) {
                    Db::name('user_profile_pending')->where('user_id', $userId)->update($pending);
                } else {
                    $pending['id'] = uuid();
                    $pending['user_id'] = $userId;
                    $pending['create_time'] = date('Y-m-d H:i:s');
                    Db::name('user_profile_pending')->insert($pending);
                }
                Db::name('users')->where('id', $userId)->update([
                    'profile_status' => 'pending',
                    'update_time'    => date('Y-m-d H:i:s')
                ]);

                return json([
                    'code'    => 200,
                    'message' => '资料已提交，待审核',
                    'data'    => ['user_id' => $userId, 'user_key' => $userKey]
                ]);
            } else {
                // 创建新用户（真实资料同样进待审快照）
                $userId = uuid();
                Db::name('users')->insert(array_merge(['id' => $userId], [
                    'user_key'        => $userKey,
                    'nickname'        => '微信用户' . substr(md5($userKey), 0, 8), // 占位，保证唯一
                    'avatar'          => '/static/images/default-avatar.jpg',
                    'gender'          => $data['gender'] ?? 0,
                    'country'         => $data['country'] ?? '',
                    'province'        => $data['province'] ?? '',
                    'city'            => $data['city'] ?? '',
                    'language'        => $data['language'] ?? '',
                    'visit_count'     => $data['visitCount'] ?? 0,
                    'like_count'      => $data['likeCount'] ?? 0,
                    'user_type'       => 'wechat',
                    'status'          => 1,
                    'role'            => '访客',
                    'profile_status'  => 'pending',
                    'create_time'     => date('Y-m-d H:i:s'),
                    'update_time'     => date('Y-m-d H:i:s')
                ]));

                Db::name('user_profile_pending')->insert([
                    'id'          => uuid(),
                    'user_id'     => $userId,
                    'nickname'    => $data['nickName'],
                    'avatar'      => $data['avatarUrl'],
                    'gender'      => $data['gender'] ?? 0,
                    'country'     => $data['country'] ?? '',
                    'province'    => $data['province'] ?? '',
                    'city'        => $data['city'] ?? '',
                    'status'      => 'pending',
                    'create_time' => date('Y-m-d H:i:s'),
                    'update_time' => date('Y-m-d H:i:s')
                ]);

                return json([
                    'code'    => 200,
                    'message' => '资料已提交，待审核',
                    'data'    => ['user_id' => $userId, 'user_key' => $userKey]
                ]);
            }
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 获取用户信息
     */
    public function getUserInfo(Request $request): Response
    {
        try {
            $userKey = $request->param('user_key', '');
            
            if (empty($userKey)) {
                return json(['code' => 400, 'message' => '用户标识不能为空']);
            }
            
            $user = Db::name('users')->where('user_key', $userKey)->find();
            
            if (!$user) {
                return json(['code' => 404, 'message' => '用户不存在']);
            }
            
            return json([
                'code' => 200,
                'message' => '获取成功',
                'data' => [
                    'nickName' => $user['nickname'],
                    'avatarUrl' => $user['avatar'],
                    'gender' => $user['gender'],
                    'country' => $user['country'],
                    'province' => $user['province'],
                    'city' => $user['city'],
                    'language' => $user['language'],
                    'visitCount' => $user['visit_count'],
                    'likeCount' => $user['like_count'],
                    'createTime' => $user['create_time'],
                    'lastLoginTime' => $user['last_login_time']
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 更新用户统计信息
     */
    public function updateUserStats(Request $request): Response
    {
        try {
            $userKey = $request->param('user_key', '');
            $type = $request->param('type', ''); // 'visit' 或 'like'
            
            if (empty($userKey) || empty($type)) {
                return json(['code' => 400, 'message' => '参数不完整']);
            }
            
            $user = Db::name('users')->where('user_key', $userKey)->find();
            
            if (!$user) {
                return json(['code' => 404, 'message' => '用户不存在']);
            }
            
            $updateData = [
                'update_time' => date('Y-m-d H:i:s')
            ];
            
            if ($type === 'visit') {
                $updateData['visit_count'] = $user['visit_count'] + 1;
            } elseif ($type === 'like') {
                $updateData['like_count'] = $user['like_count'] + 1;
            } else {
                return json(['code' => 400, 'message' => '无效的统计类型']);
            }
            
            Db::name('users')->where('id', $user['id'])->update($updateData);
            
            return json([
                'code' => 200,
                'message' => '更新成功',
                'data' => $updateData
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    // ========================================================
    // 后台审核：封面审核 / 资料审核
    // ========================================================

    /**
     * 后台：封面审核列表（user_covers）
     */
    public function coverList(Request $request): Response
    {
        try {
            $status  = $request->param('status', 'all');
            $keyword = $request->param('keyword', '');
            $page    = (int) $request->param('page', 1);
            $limit   = (int) $request->param('limit', 10);

            $query = Db::name('user_covers')->alias('c')
                ->leftJoin('users u', 'u.id = c.user_id')
                ->field('c.id, c.user_id, c.image, c.status, c.reject_reason, c.create_time, u.nickname as user_name, u.avatar as user_avatar');

            if ($status && $status !== 'all') {
                $query->where('c.status', $status);
            }
            if ($keyword) {
                $query->where('u.nickname', 'like', "%$keyword%");
            }

            $list = $query->order('c.create_time', 'desc')
                ->paginate(['list_rows' => $limit, 'page' => $page]);

            return json([
                'code'    => 200,
                'message' => '获取成功',
                'data'    => [
                    'list'  => $list->items(),
                    'total' => $list->total(),
                    'page'  => $page,
                    'limit' => $limit
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 后台：封面审核通过 / 驳回
     */
    public function coverReview(Request $request): Response
    {
        try {
            $coverId = $request->param('cover_id', '');
            $action  = $request->param('action', '');
            $reason  = $request->param('reason', '');

            if (!$coverId || !in_array($action, ['approve', 'reject'])) {
                return json(['code' => 400, 'message' => '参数错误']);
            }
            $cover = Db::name('user_covers')->where('id', $coverId)->find();
            if (!$cover) {
                return json(['code' => 404, 'message' => '封面记录不存在']);
            }

            if ($action === 'approve') {
                Db::name('user_covers')->where('id', $coverId)->update([
                    'status'      => 'approved',
                    'audit_time'  => date('Y-m-d H:i:s'),
                    'update_time' => date('Y-m-d H:i:s')
                ]);
                $msg = '已通过';
            } else {
                if (!$reason) {
                    return json(['code' => 400, 'message' => '请填写驳回原因']);
                }
                Db::name('user_covers')->where('id', $coverId)->update([
                    'status'        => 'rejected',
                    'reject_reason' => $reason,
                    'audit_time'    => date('Y-m-d H:i:s'),
                    'update_time'   => date('Y-m-d H:i:s')
                ]);
                $msg = '已驳回';
            }

            return json(['code' => 200, 'message' => $msg]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 后台：资料审核列表（users.profile_status + 待审快照）
     */
    public function profileReviewList(Request $request): Response
    {
        try {
            $status  = $request->param('status', 'pending');
            $keyword = $request->param('keyword', '');
            $page    = (int) $request->param('page', 1);
            $limit   = (int) $request->param('limit', 10);

            $where = [];
            if ($status && $status !== 'all') {
                $where[] = ['u.profile_status', '=', $status];
            }
            if ($keyword) {
                $where[] = ['u.nickname', 'like', "%$keyword%"];
            }

            $rows = Db::name('users')->alias('u')
                ->leftJoin('user_profile_pending p', 'p.user_id = u.id')
                ->where($where)
                ->field([
                    'u.id', 'u.nickname as current_nickname', 'u.avatar as current_avatar',
                    'u.gender as current_gender', 'u.profile_status', 'u.profile_reject_reason',
                    'u.profile_audit_time',
                    'p.nickname as new_nickname', 'p.avatar as new_avatar', 'p.gender as new_gender',
                    'p.country as new_country', 'p.province as new_province', 'p.city as new_city',
                    'p.code_age as new_code_age', 'p.address as new_address',
                    'p.github as new_github', 'p.web_url as new_web_url',
                    'p.status as pending_status', 'p.reject_reason as pending_reason',
                    'p.create_time as submit_time'
                ])
                ->order('p.create_time', 'desc')
                ->paginate(['list_rows' => $limit, 'page' => $page]);

            return json([
                'code'    => 200,
                'message' => '获取成功',
                'data'    => [
                    'list'  => $rows->items(),
                    'total' => $rows->total(),
                    'page'  => $page,
                    'limit' => $limit
                ]
            ]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 后台：资料审核通过 / 驳回
     * 通过：将待审快照覆盖到 users，资料对外生效；
     * 驳回：标记 users.profile_status=rejected 并记录原因（users 资料保持原样）。
     */
    public function profileReview(Request $request): Response
    {
        try {
            $userId = $request->param('user_id', '');
            $action = $request->param('action', '');
            $reason = $request->param('reason', '');

            if (!$userId || !in_array($action, ['approve', 'reject'])) {
                return json(['code' => 400, 'message' => '参数错误']);
            }
            $user = Db::name('users')->where('id', $userId)->find();
            if (!$user) {
                return json(['code' => 404, 'message' => '用户不存在']);
            }
            $pending = Db::name('user_profile_pending')->where('user_id', $userId)->find();

            if ($action === 'approve') {
                if (!$pending) {
                    return json(['code' => 400, 'message' => '该用户暂无待审资料']);
                }
                $upd = [];
                foreach (['nickname', 'avatar', 'gender', 'country', 'province', 'city', 'code_age', 'address', 'github', 'web_url'] as $f) {
                    if (isset($pending[$f]) && $pending[$f] !== null && $pending[$f] !== '') {
                        $upd[$f] = $pending[$f];
                    }
                }
                $upd['profile_status']     = 'approved';
                $upd['profile_audit_time'] = date('Y-m-d H:i:s');
                $upd['update_time']        = date('Y-m-d H:i:s');
                Db::name('users')->where('id', $userId)->update($upd);
                Db::name('user_profile_pending')->where('user_id', $userId)
                    ->update(['status' => 'approved', 'update_time' => date('Y-m-d H:i:s')]);
                $msg = '已通过，资料已生效';
            } else {
                if (!$reason) {
                    return json(['code' => 400, 'message' => '请填写驳回原因']);
                }
                Db::name('users')->where('id', $userId)->update([
                    'profile_status'        => 'rejected',
                    'profile_reject_reason' => $reason,
                    'profile_audit_time'    => date('Y-m-d H:i:s'),
                    'update_time'           => date('Y-m-d H:i:s')
                ]);
                if ($pending) {
                    Db::name('user_profile_pending')->where('user_id', $userId)->update([
                        'status'        => 'rejected',
                        'reject_reason' => $reason,
                        'update_time'   => date('Y-m-d H:i:s')
                    ]);
                }
                $msg = '已驳回';
            }

            return json(['code' => 200, 'message' => $msg]);
        } catch (\Exception $e) {
            return json(['code' => 500, 'message' => '服务器错误：' . $e->getMessage()]);
        }
    }

    /**
     * 解析请求中的角色集合：优先 role_ids(数组)，回退单 role_id；均无则返回 null
     */
    private function parseRoleIds(Request $request): ?array
    {
        $ids = $request->param('role_ids/a');
        if (is_array($ids) && count($ids) > 0) {
            return array_values(array_unique(array_map('intval', $ids)));
        }
        $single = $request->param('role_id');
        if ($single !== '' && $single !== null) {
            return [(int) $single];
        }
        return null;
    }

    /**
     * 同步用户-角色关联（全量替换）
     */
    private function syncUserRoles(string $userId, array $roleIds): void
    {
        Db::name('user_roles')->where('user_id', $userId)->delete();
        foreach ($roleIds as $rid) {
            if ($rid > 0) {
                Db::name('user_roles')->insert([
                    'id'          => uuid(),
                    'user_id'     => $userId,
                    'role_id'     => (int) $rid,
                    'create_time' => date('Y-m-d H:i:s')
                ]);
            }
        }
    }
} 