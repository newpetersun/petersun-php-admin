<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Route;

// 全局CORS中间件

    // 微信登录相关接口（无需认证）
    Route::group('wechat', function () {
        Route::post('login', 'WechatAuth/login'); // 微信登录
        Route::post('complete-info', 'WechatAuth/completeUserInfo'); // 完善用户信息
        Route::get('verify-token', 'WechatAuth/verifyToken'); // 验证token
    });

    // 小程序端确认后台扫码登录（需用户 JWT）
    Route::post('wechat/scan-confirm', 'WechatAuth/scanConfirm')->middleware('JwtAuth');

    // 需要认证的接口
    Route::group('auth', function () {
        Route::get('profile', 'Auth/profile'); // 获取用户信息
        Route::post('refresh', 'Auth/refresh'); // 刷新token
        Route::post('logout', 'Auth/logout'); // 用户登出
    })->middleware('JwtAuth');

    // 用户相关接口
    Route::group('user', function () {
        Route::get('info', 'User/info'); // 获取用户信息
        Route::get('splash-data', 'User/getSplashData'); // 获取启动页数据
        Route::post('update', 'User/update'); // 更新用户信息
        Route::get('map-data', 'User/mapData'); // 获取地图数据
        Route::post('save-info', 'User/saveUserInfo'); // 保存微信用户信息
        Route::get('get-info', 'User/getUserInfo'); // 获取微信用户信息
        Route::post('update-stats', 'User/updateUserStats'); // 更新用户统计信息
        Route::post('upload-avatar', 'User/uploadAvatar'); // 上传用户头像
        Route::post('upload-cover', 'User/uploadCover')->middleware('JwtAuth'); // 上传用户封面(需登录,默认待审核)
    });

    // 后台用户管理接口（需管理员）
    Route::group('user', function () {
        Route::get('list', 'User/list');            // 用户列表
        Route::post('create', 'User/create');        // 新建用户
        Route::post('update', 'User/update');        // 更新用户（角色/状态等）
        Route::post('delete', 'User/delete');        // 删除用户
    })->middleware(['JwtAuth', 'AdminAuth']);

    // 联系相关接口需鉴权
    Route::group('contact', function () {
        Route::post('update', 'Contact/update'); // 更新联系信息
        Route::get('messages', 'Contact/messages'); // 获取留言列表
        Route::post('read/:id', 'Contact/markAsRead'); // 标记留言为已读
        Route::delete('message/:id', 'Contact/deleteMessage'); // 删除留言
        Route::get('stats', 'Contact/stats'); // 获取留言统计
        Route::post('batch-read', 'Contact/batchMarkAsRead'); // 批量标记为已读
        Route::post('batch-delete', 'Contact/batchDelete'); // 批量删除留言
    })->middleware('JwtAuth');

    // 联系相关接口无需鉴权
    Route::group('contact', function () {
        Route::get('info', 'Contact/info'); // 获取联系信息
        Route::post('update', 'Contact/update'); // 更新联系信息
        Route::get('messages', 'Contact/messages'); // 获取留言列表
        Route::post('message', 'Contact/message'); // 提交留言
        Route::post('read/:id', 'Contact/markAsRead'); // 标记留言为已读
        Route::delete('message/:id', 'Contact/deleteMessage'); // 删除留言
        Route::get('stats', 'Contact/stats'); // 获取留言统计
        Route::post('batch-read', 'Contact/batchMarkAsRead'); // 批量标记为已读
        Route::post('batch-delete', 'Contact/batchDelete'); // 批量删除留言
    });

    // 后台管理接口
    Route::group('admin', function () {
        Route::get('dashboard', 'Admin/dashboard'); // 获取仪表盘数据
        Route::get('stats', 'Admin/stats'); // 获取系统统计
        Route::get('visit-trend', 'Admin/visitTrend'); // 获取访问趋势
        Route::get('popular-pages', 'Admin/popularPages'); // 获取热门页面
        Route::get('system-info', 'Admin/systemInfo'); // 获取系统信息
        Route::get('menu', 'Menu/index'); // 获取当前角色的后台菜单（数据库驱动）
        Route::get('roles', 'Menu/roleList');        // 角色列表
        Route::post('roles', 'Menu/roleSave');        // 角色新增/更新
        Route::delete('roles/:id', 'Menu/roleDelete'); // 角色删除
        Route::get('menus', 'Menu/menuList');         // 菜单列表
        Route::post('menus', 'Menu/menuSave');         // 菜单新增/更新
        Route::delete('menus/:id', 'Menu/menuDelete'); // 菜单删除
        // 封面审核 / 资料审核
        Route::get('covers', 'User/coverList');               // 封面审核列表
        Route::post('cover-review', 'User/coverReview');        // 封面审核通过/驳回
        Route::get('profile-reviews', 'User/profileReviewList'); // 资料审核列表
        Route::post('profile-review', 'User/profileReview');     // 资料审核通过/驳回
    })->middleware(['JwtAuth', 'AdminAuth']);

    // 后台登录（公开，无需鉴权）
    Route::group('admin', function () {
        Route::get('captcha', 'WechatAuth/captcha');                // 获取登录图形验证码
        Route::post('password-login', 'WechatAuth/passwordLogin'); // 管理员密码登录
        Route::post('scan-ticket', 'WechatAuth/scanTicket');        // 创建扫码登录票据+小程序码
        Route::get('scan-status', 'WechatAuth/scanStatus');         // 轮询扫码状态
    });

    // 系统设置接口
    Route::group('setting', function () {
        Route::get('list', 'Setting/getSettings'); // 获取系统设置
        Route::post('update', 'Setting/updateSettings'); // 更新系统设置
        Route::get('system-info', 'Setting/getSystemInfo'); // 获取系统信息
        Route::post('backup', 'Setting/backupData'); // 备份数据
        Route::post('restore', 'Setting/restoreData'); // 恢复数据
        Route::post('clear-cache', 'Setting/clearCache'); // 清除缓存
        Route::get('backup-list', 'Setting/getBackupList'); // 获取备份列表
        Route::delete('backup/:filename', 'Setting/deleteBackup'); // 删除备份文件
    })->middleware(['JwtAuth', 'AdminAuth']);

    // 访问统计接口
    Route::group('visit', function () {
        Route::post('log', 'Visit/log'); // 记录访问日志
        Route::get('stats', 'Visit/stats'); // 获取访问统计
        Route::get('trend', 'Visit/trend'); // 获取访问趋势
        Route::get('realtime', 'Visit/realtime'); // 获取实时访问数据
        Route::get('geo', 'Visit/geo'); // 获取地理位置统计
    });

    // 虚拟支付（个人主体，道具直购）
    Route::group('pay', function () {
        Route::get('goods', 'Pay/goods');                  // 道具列表
        Route::get('status', 'Pay/status');                // 订单状态（前端轮询）
        Route::post('order', 'Pay/order');                 // 下单，返回 payData
        Route::get('wallet', 'Pay/wallet');                // 钱包余额 + 购买记录
    })->middleware('JwtAuth');

    Route::group('pay', function () {
        Route::post('query', 'Pay/query');                 // 手动兜底查单
    })->middleware(['JwtAuth', 'AdminAuth']);

    // 发货推送：微信平台回调（GET 用于 Token 验证握手，POST 用于发货推送），不能挂登录态中间件
    Route::rule('pay/notify', 'Pay/notify', 'GET|POST');

    // 论坛板块接口（读，无需鉴权）
    Route::group('board', function () {
        Route::get('list', 'Board/list');           // 板块列表
        Route::get('detail', 'Board/detail');        // 板块详情（公告/版主/置顶/最新帖子）
    });

    // 论坛板块写操作（需登录）
    Route::group('board', function () {
        Route::post('join', 'Board/join');           // 加入/退出板块
        Route::post('follow', 'Board/follow');       // 关注/取消关注版主
    })->middleware('JwtAuth');

    // 论坛板块管理（管理端，需管理员）
    Route::group('board', function () {
        Route::get('admin-list', 'Board/adminList');   // 板块列表（含禁用）
        Route::post('create', 'Board/create');          // 创建板块
        Route::post('update/:id', 'Board/update');      // 更新板块
        Route::delete('delete/:id', 'Board/delete');    // 删除板块
        Route::post('status/:id', 'Board/status');      // 更新板块状态
    })->middleware(['JwtAuth', 'AdminAuth']);

    // 论坛帖子接口（读，无需鉴权；detail 内自行解析 token 判断已购）
    Route::group('post', function () {
        Route::get('list', 'Post/list');             // 帖子列表（可按板块/分类/关键词/精华/排序）
        Route::get('detail/:id', 'Post/detail')->pattern(['id' => '[\w-]+']);     // 帖子详情（正文/评论/点赞态），id 为 UUID 含连字符
        Route::get('comments/:id', 'Post/comments')->pattern(['id' => '[\w-]+']);  // 评论列表，id 为 UUID 含连字符
        Route::get('poster-code', 'Post/posterCode');                            // 生成帖子分享小程序码（海报用）
    });

    // 论坛帖子写操作（需登录）
    Route::group('post', function () {
        Route::post('create', 'Post/create');        // 发布帖子
        Route::post('upload-image', 'Post/uploadImage'); // 帖子图片上传
        Route::post('like', 'Post/like');            // 点赞/取消点赞
        Route::post('comment', 'Post/comment');      // 发表评论
        Route::post('buy', 'Post/buy');              // 金币购买解锁付费帖正文
        Route::post('report', 'Post/report');        // 举报帖子
        Route::delete('delete/:id', 'Post/delete');  // 删除帖子(管理员)
        Route::post('update/:id', 'Post/update');    // 更新帖子(管理员)
    })->middleware('JwtAuth');

    // ========================================================
    // 创作者内容：图文 / 视频 / 草稿 / 发布审核
    // ========================================================

    // 创作者端（需登录，操作范围限定为本人内容）
    Route::group('article', function () {
        Route::get('list', 'Article/list');                // 内容列表（type/status/keyword 分页）
        Route::get('detail/:id', 'Article/detail')->pattern(['id' => '[\w-]+']);
        Route::post('save', 'Article/save');              // 新建（submit=1 直接提交审核）
        Route::post('update/:id', 'Article/update')->pattern(['id' => '[\w-]+']);
        Route::delete('delete/:id', 'Article/delete')->pattern(['id' => '[\w-]+']);
        Route::post('toggle-status/:id', 'Article/toggleStatus')->pattern(['id' => '[\w-]+']); // 上下架/重新提交
        Route::post('batch', 'Article/batch');              // 批量：下架/上架/提交审核/删除
        Route::get('drafts', 'Article/drafts');            // 草稿箱
        Route::get('categories', 'Article/categories');    // 分类字典
        Route::post('upload-video', 'Article/uploadVideo'); // 视频上传
        Route::post('upload-image', 'Article/uploadImage'); // 图片上传（编辑器内嵌/封面）
    })->middleware('JwtAuth');

    // 管理端内容审核（需管理员）
    Route::group('article', function () {
        Route::get('admin-list', 'Article/adminList');      // 全部创作者内容
        Route::get('admin-detail/:id', 'Article/detail')->pattern(['id' => '[\w-]+']); // 查看任意状态内容（审核用）
        Route::post('review/:id', 'Article/review')->pattern(['id' => '[\w-]+']); // 审核通过/驳回
    })->middleware(['JwtAuth', 'AdminAuth']);

    // 创作者数据看板（概览 / 内容数据 / 粉丝画像，需登录）
    Route::group('creator', function () {
        Route::get('overview', 'Creator/overview');           // 概览：核心指标 + 待办 + 认证状态
        Route::get('content-stats', 'Creator/contentStats');  // 内容数据：指标 + 热门Top + 趋势
        Route::get('fans', 'Creator/fans');                  // 粉丝画像：总数/活跃/性别/城市
        Route::get('announcements', 'Creator/announcements'); // 官方公告
    })->middleware('JwtAuth');

    // 收益 / 提现 / 付费订单（需登录）
    Route::group('earning', function () {
        Route::get('overview', 'Earning/overview');        // 收益概览：钱包/累计/来源构成
        Route::get('trend', 'Earning/trend');              // 收益趋势：range=7|30|365
        Route::get('withdraw-list', 'Earning/withdrawList'); // 提现记录
        Route::post('apply-withdraw', 'Earning/applyWithdraw'); // 申请提现
        Route::get('orders', 'Earning/orders');            // 付费订单（谁买了我的内容）
    })->middleware('JwtAuth');

    // 站内私信（需登录）
    Route::group('message', function () {
        Route::get('conversations', 'Message/conversations'); // 会话列表
        Route::get('messages', 'Message/messages');           // 会话消息（自动已读）
        Route::post('send', 'Message/send');                  // 发送私信
        Route::get('unread-count', 'Message/unreadCount');    // 未读总数
    })->middleware('JwtAuth');

    // 违规申诉（需登录）
    Route::group('appeal', function () {
        Route::get('list', 'Appeal/list');
        Route::get('targets', 'Appeal/targetList');        // 可申诉的内容
        Route::post('create', 'Appeal/create');
        Route::post('cancel/:id', 'Appeal/cancel')->pattern(['id' => '[\w-]+']);
    })->middleware('JwtAuth');

    // 账号绑定（需登录）
    Route::group('account', function () {
        Route::get('list', 'Account/list');
        Route::post('bind', 'Account/bind');
        Route::post('unbind', 'Account/unbind');
    })->middleware('JwtAuth');

    // 论坛首页聚合接口（热门话题 / 推荐阅读 / 活跃作者，只读免鉴权）
    Route::group('forum', function () {
        Route::get('hot-topics', 'Forum/hotTopics');        // 热门话题
        Route::get('recommended', 'Forum/recommended');      // 推荐阅读
        Route::get('active-authors', 'Forum/activeAuthors'); // 活跃作者
    });

    // 综合搜索（文章 / 板块 / 用户，只读免鉴权）
    Route::get('search', 'Search/index');

    // 用户认证接口（需登录）
    Route::group('certify', function () {
        Route::post('submit', 'Certification/submit'); // 提交认证申请
        Route::get('mine', 'Certification/mine');      // 我的认证申请状态
    })->middleware('JwtAuth');

    // 后台认证审核（需管理员）
    Route::group('certify', function () {
        Route::get('list', 'Certification/list');     // 认证申请列表
        Route::post('review', 'Certification/review'); // 审核通过/驳回
    })->middleware(['JwtAuth', 'AdminAuth']);

    // 用户认证查询（公开，按 userId 查认证状态/类型，用于主页徽章）
    Route::get('certify/status', 'Certification/status');

    // 用户关注接口（需登录）
    Route::group('follow', function () {
        Route::post('toggle', 'Follow/toggle'); // 关注/取消关注
        Route::get('status', 'Follow/status');  // 查询关注状态
    })->middleware('JwtAuth');

// 默认路由
Route::get('/', 'Index/index');
